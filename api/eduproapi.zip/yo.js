// const phone = "long";
// const peter = "peter";
// const john = "koe";
// module.exports = { john, peter };
